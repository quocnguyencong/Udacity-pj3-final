/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9941164934300843, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "PUT Activity"], "isController": false}, {"data": [0.9257425742574258, 500, 1500, "GET all Activity"], "isController": false}, {"data": [1.0, 500, 1500, "DELETE User"], "isController": false}, {"data": [1.0, 500, 1500, "GET Activitiy"], "isController": false}, {"data": [1.0, 500, 1500, "DELETE CoverPhoto"], "isController": false}, {"data": [1.0, 500, 1500, "GET Book"], "isController": false}, {"data": [0.9318181818181818, 500, 1500, "GET all Author"], "isController": false}, {"data": [1.0, 500, 1500, "GET all User"], "isController": false}, {"data": [1.0, 500, 1500, "PUT Book"], "isController": false}, {"data": [1.0, 500, 1500, "PUT Author"], "isController": false}, {"data": [1.0, 500, 1500, "GET User"], "isController": false}, {"data": [1.0, 500, 1500, "POST Activity"], "isController": false}, {"data": [1.0, 500, 1500, "POST CoverPhoto"], "isController": false}, {"data": [1.0, 500, 1500, "GET Author"], "isController": false}, {"data": [1.0, 500, 1500, "GET CoverPhoto"], "isController": false}, {"data": [1.0, 500, 1500, "DELETE Author"], "isController": false}, {"data": [1.0, 500, 1500, "GET Author for Book"], "isController": false}, {"data": [1.0, 500, 1500, "GET all CoverPhoto"], "isController": false}, {"data": [1.0, 500, 1500, "GET all Book"], "isController": false}, {"data": [1.0, 500, 1500, "DELETE Activity"], "isController": false}, {"data": [0.9923469387755102, 500, 1500, "POST Author"], "isController": false}, {"data": [1.0, 500, 1500, "DELETE Book"], "isController": false}, {"data": [1.0, 500, 1500, "POST User"], "isController": false}, {"data": [1.0, 500, 1500, "PUT User"], "isController": false}, {"data": [1.0, 500, 1500, "POST Book"], "isController": false}, {"data": [1.0, 500, 1500, "GET CoverPhotos for Book"], "isController": false}, {"data": [1.0, 500, 1500, "PUT CoverPhoto"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 5099, 0, 0.0, 267.6607177878016, 241, 1394, 259.0, 278.0, 285.0, 508.0, 84.95784597953947, 1597.0631499352278, 46.779032696441064], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["PUT Activity", 199, 0, 0.0, 257.67839195979883, 243, 297, 257.0, 266.0, 271.0, 288.0, 3.452643267345629, 10.474550717204226, 1.0886256603830873], "isController": false}, {"data": ["GET all Activity", 202, 0, 0.0, 375.1534653465349, 243, 1394, 258.0, 1030.1000000000001, 1048.7, 1085.67, 3.3692497581479133, 10.217289635595623, 0.5396064065783768], "isController": false}, {"data": ["DELETE User", 176, 0, 0.0, 257.4545454545453, 242, 417, 256.0, 263.0, 267.15, 353.85999999999916, 3.3951272208183028, 0.6995818785084589, 0.8192620722332606], "isController": false}, {"data": ["GET Activitiy", 200, 0, 0.0, 256.155, 242, 368, 255.0, 262.0, 264.95, 303.9000000000001, 3.460387217329619, 1.1921270513607973, 0.5632760188677614], "isController": false}, {"data": ["DELETE CoverPhoto", 182, 0, 0.0, 257.06043956043953, 242, 323, 255.0, 265.0, 268.85, 322.16999999999996, 3.409580546656925, 0.7025600540474719, 0.8470896209183387], "isController": false}, {"data": ["GET Book", 189, 0, 0.0, 263.6243386243386, 246, 300, 262.0, 274.0, 279.5, 291.9, 3.4507942304181123, 2.5110868461292677, 0.5473706808015336], "isController": false}, {"data": ["GET all Author", 198, 0, 0.0, 302.6616161616161, 249, 534, 266.0, 508.0, 517.0, 527.0699999999999, 3.4610543979862958, 163.40855067800834, 0.5441696856208922], "isController": false}, {"data": ["GET all User", 178, 0, 0.0, 256.42134831460686, 242, 317, 255.0, 264.1, 269.0, 300.4100000000002, 3.379853792841546, 2.5877005601443086, 0.5248015166619197], "isController": false}, {"data": ["PUT Book", 187, 0, 0.0, 280.41176470588243, 259, 313, 280.0, 291.0, 296.6, 308.6, 3.4433866720680575, 327.9341363106966, 16.058983821146445], "isController": false}, {"data": ["PUT Author", 191, 0, 0.0, 267.82198952879577, 250, 408, 265.0, 276.8, 284.4, 400.6399999999999, 3.460834586602403, 164.34591882553588, 1.017844645219156], "isController": false}, {"data": ["GET User", 176, 0, 0.0, 257.16477272727286, 243, 387, 255.0, 265.0, 269.0, 341.56999999999937, 3.395454720839603, 1.0288817125342438, 0.5341759571420303], "isController": false}, {"data": ["POST Activity", 201, 0, 0.0, 257.2985074626867, 243, 308, 257.0, 265.0, 268.0, 282.96, 3.460803388488094, 10.49837895904716, 1.0888993870417878], "isController": false}, {"data": ["POST CoverPhoto", 184, 0, 0.0, 262.5706521739131, 247, 440, 259.0, 270.0, 275.0, 361.8000000000005, 3.4282307348338055, 69.43171602511552, 1.0941750354002087], "isController": false}, {"data": ["GET Author", 194, 0, 0.0, 256.62371134020617, 244, 299, 256.0, 264.0, 270.0, 289.5000000000001, 3.450974811441583, 1.1296411386438026, 0.5541891432154546], "isController": false}, {"data": ["GET CoverPhoto", 181, 0, 0.0, 256.1325966850827, 243, 279, 256.0, 263.0, 265.0, 277.36, 3.404687558782589, 1.2008180772920507, 0.5599225304258681], "isController": false}, {"data": ["DELETE Author", 194, 0, 0.0, 256.0051546391753, 242, 324, 256.0, 263.0, 267.0, 277.45000000000056, 3.44993153486387, 0.7108745643127701, 0.8437619480554124], "isController": false}, {"data": ["GET Author for Book", 198, 0, 0.0, 257.45454545454555, 243, 374, 255.0, 265.1, 270.09999999999997, 330.4399999999996, 3.4614174329568894, 1.6636150724625014, 0.5626647123352331], "isController": false}, {"data": ["GET all CoverPhoto", 185, 0, 0.0, 261.0648648648649, 245, 347, 259.0, 270.0, 276.7, 302.2799999999993, 3.426497008760719, 69.39660299285993, 0.5521211000444518], "isController": false}, {"data": ["GET all Book", 191, 0, 0.0, 279.3193717277488, 258, 372, 278.0, 291.0, 295.79999999999995, 337.9599999999994, 3.461210880162369, 329.6083280573274, 0.5374341112752116], "isController": false}, {"data": ["DELETE Activity", 201, 0, 0.0, 257.53731343283573, 242, 358, 256.0, 263.0, 266.9, 333.8399999999999, 3.4611013534456037, 0.7131761577900609, 0.854075995712367], "isController": false}, {"data": ["POST Author", 196, 0, 0.0, 270.96938775510205, 246, 525, 264.0, 275.0, 284.5499999999996, 521.12, 3.4656529042524977, 162.23209500154718, 1.014516427592609], "isController": false}, {"data": ["DELETE Book", 190, 0, 0.0, 256.26315789473676, 241, 322, 256.0, 264.0, 268.0, 293.7900000000001, 3.4619098810196234, 0.7133427586866606, 0.8398903690578139], "isController": false}, {"data": ["POST User", 176, 0, 0.0, 256.01704545454544, 243, 282, 256.0, 264.0, 266.0, 273.52999999999986, 3.3948652662847443, 2.599193719499257, 0.8924556473390814], "isController": false}, {"data": ["PUT User", 173, 0, 0.0, 257.75144508670536, 242, 428, 256.0, 266.2, 270.29999999999995, 324.3999999999987, 3.35024594291026, 2.565032050040668, 0.881058401758395], "isController": false}, {"data": ["POST Book", 191, 0, 0.0, 280.4240837696336, 261, 337, 279.0, 292.0, 300.4, 335.15999999999997, 3.461963712820141, 329.70616356419134, 16.18814614448714], "isController": false}, {"data": ["GET CoverPhotos for Book", 187, 0, 0.0, 257.3048128342247, 242, 304, 256.0, 267.0, 277.6, 293.44000000000005, 3.4438939943645375, 1.2215708967936794, 0.556345132967458], "isController": false}, {"data": ["PUT CoverPhoto", 179, 0, 0.0, 261.5251396648045, 246, 325, 260.0, 272.0, 276.0, 314.59999999999985, 3.388996175546215, 68.63710125454391, 1.0861664702374192], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 5099, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
