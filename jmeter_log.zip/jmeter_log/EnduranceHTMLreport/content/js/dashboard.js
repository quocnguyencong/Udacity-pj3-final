/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9964979863421467, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "PUT Activity"], "isController": false}, {"data": [0.9314159292035398, 500, 1500, "GET all Activity"], "isController": false}, {"data": [1.0, 500, 1500, "DELETE User"], "isController": false}, {"data": [1.0, 500, 1500, "GET Activitiy"], "isController": false}, {"data": [1.0, 500, 1500, "DELETE CoverPhoto"], "isController": false}, {"data": [1.0, 500, 1500, "GET Book"], "isController": false}, {"data": [0.9977272727272727, 500, 1500, "GET all Author"], "isController": false}, {"data": [1.0, 500, 1500, "GET all User"], "isController": false}, {"data": [1.0, 500, 1500, "PUT Book"], "isController": false}, {"data": [1.0, 500, 1500, "PUT Author"], "isController": false}, {"data": [1.0, 500, 1500, "GET User"], "isController": false}, {"data": [1.0, 500, 1500, "POST Activity"], "isController": false}, {"data": [1.0, 500, 1500, "POST CoverPhoto"], "isController": false}, {"data": [1.0, 500, 1500, "GET Author"], "isController": false}, {"data": [1.0, 500, 1500, "GET CoverPhoto"], "isController": false}, {"data": [1.0, 500, 1500, "DELETE Author"], "isController": false}, {"data": [1.0, 500, 1500, "GET Author for Book"], "isController": false}, {"data": [1.0, 500, 1500, "GET all CoverPhoto"], "isController": false}, {"data": [0.9883720930232558, 500, 1500, "GET all Book"], "isController": false}, {"data": [1.0, 500, 1500, "DELETE Activity"], "isController": false}, {"data": [1.0, 500, 1500, "POST Author"], "isController": false}, {"data": [1.0, 500, 1500, "DELETE Book"], "isController": false}, {"data": [1.0, 500, 1500, "POST User"], "isController": false}, {"data": [1.0, 500, 1500, "PUT User"], "isController": false}, {"data": [0.9929906542056075, 500, 1500, "POST Book"], "isController": false}, {"data": [1.0, 500, 1500, "GET CoverPhotos for Book"], "isController": false}, {"data": [1.0, 500, 1500, "PUT CoverPhoto"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 5711, 0, 0.0, 238.77814743477435, 219, 2017, 230.0, 247.0, 253.0, 451.8800000000001, 95.2309488077372, 1914.202234580832, 51.35676562239453], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["PUT Activity", 221, 0, 0.0, 229.0950226244344, 220, 254, 228.0, 236.8, 241.89999999999998, 252.34, 3.876716894416475, 13.030455004429282, 1.180621869901942], "isController": false}, {"data": ["GET all Activity", 226, 0, 0.0, 328.070796460177, 220, 2017, 228.0, 919.3, 936.65, 1126.9599999999984, 3.7686766275346852, 12.668051867245863, 0.5630932851687567], "isController": false}, {"data": ["DELETE User", 199, 0, 0.0, 228.05025125628146, 220, 254, 226.0, 237.0, 242.0, 253.0, 3.9169373093199487, 2.092348347849621, 0.903096859315028], "isController": false}, {"data": ["GET Activitiy", 221, 0, 0.0, 228.08597285067887, 220, 268, 226.0, 237.0, 240.0, 256.9, 3.875629132104589, 2.606798325894814, 0.5891948205110218], "isController": false}, {"data": ["DELETE CoverPhoto", 206, 0, 0.0, 230.68932038834947, 221, 257, 229.0, 240.0, 243.64999999999998, 255.93, 3.9887694839771513, 2.130719636460451, 0.9481798818859521], "isController": false}, {"data": ["GET Book", 212, 0, 0.0, 234.69811320754724, 223, 314, 233.0, 243.0, 250.35, 281.31000000000006, 3.9811458939738222, 4.331674815965898, 0.5885856310210137], "isController": false}, {"data": ["GET all Author", 220, 0, 0.0, 259.7181818181817, 224, 555, 234.5, 446.9, 461.0, 478.15999999999997, 3.895391044141863, 181.13404087615314, 0.5706139224817183], "isController": false}, {"data": ["GET all User", 202, 0, 0.0, 227.3762376237623, 220, 249, 226.0, 235.0, 238.0, 246.88, 3.94677712432348, 4.316787479728806, 0.5704326312498779], "isController": false}, {"data": ["PUT Book", 209, 0, 0.0, 250.54066985645926, 236, 422, 249.0, 259.0, 266.0, 287.20000000000005, 3.9521207193237906, 392.5560206316302, 18.420916368445436], "isController": false}, {"data": ["PUT Author", 215, 0, 0.0, 238.2883720930232, 224, 317, 236.0, 249.0, 252.0, 303.5600000000001, 3.8904169079328317, 182.61487261711963, 1.1031742239523017], "isController": false}, {"data": ["GET User", 197, 0, 0.0, 228.50761421319785, 219, 349, 226.0, 234.0, 239.1, 342.1400000000001, 3.915333399582629, 2.471131092864951, 0.5739039364503628], "isController": false}, {"data": ["POST Activity", 222, 0, 0.0, 229.9054054054054, 221, 293, 228.0, 239.0, 245.0, 279.1000000000003, 3.8364497286835104, 12.893136189645043, 1.1658299184754433], "isController": false}, {"data": ["POST CoverPhoto", 206, 0, 0.0, 232.74757281553403, 223, 284, 231.0, 241.3, 250.0, 262.86, 3.9897737837000316, 82.11375243308413, 1.2305761809536722], "isController": false}, {"data": ["GET Author", 216, 0, 0.0, 229.12962962962968, 221, 309, 227.0, 238.3, 242.14999999999998, 252.82999999999998, 3.8842633386682013, 2.546694611034185, 0.5822601782085634], "isController": false}, {"data": ["GET CoverPhoto", 206, 0, 0.0, 228.53398058252415, 220, 260, 226.0, 237.3, 244.0, 259.86, 3.989155693261038, 2.7159746260166537, 0.6132449409372579], "isController": false}, {"data": ["DELETE Author", 218, 0, 0.0, 229.9678899082568, 221, 254, 229.0, 238.0, 242.04999999999998, 250.43, 3.8906339234723015, 2.078297613417333, 0.9099850308752142], "isController": false}, {"data": ["GET Author for Book", 220, 0, 0.0, 230.6181818181817, 222, 249, 229.0, 238.0, 242.95, 248.0, 3.8946324883161028, 3.170992898934287, 0.590954467099207], "isController": false}, {"data": ["GET all CoverPhoto", 206, 0, 0.0, 232.3252427184466, 223, 260, 231.0, 240.0, 246.0, 254.0, 3.9893101979162635, 82.10421134871606, 0.5999548539835006], "isController": false}, {"data": ["GET all Book", 215, 0, 0.0, 269.41395348837216, 234, 1706, 247.0, 260.0, 266.99999999999994, 1278.72, 3.8897130658175634, 429.78076760208234, 0.5621850915439447], "isController": false}, {"data": ["DELETE Activity", 221, 0, 0.0, 228.28506787330323, 219, 278, 226.0, 235.8, 239.89999999999998, 270.26, 3.872573070722647, 2.068649872739539, 0.9139658499509358], "isController": false}, {"data": ["POST Author", 219, 0, 0.0, 237.5114155251142, 224, 480, 234.0, 247.0, 252.0, 263.8, 3.8919495290563355, 178.67261779145193, 1.0979950184378886], "isController": false}, {"data": ["DELETE Book", 213, 0, 0.0, 231.40375586854452, 222, 303, 230.0, 241.0, 243.0, 254.85999999999999, 3.986151398895855, 2.1293211085898753, 0.9240929400205857], "isController": false}, {"data": ["POST User", 199, 0, 0.0, 227.72361809045225, 220, 257, 226.0, 236.0, 240.0, 252.0, 3.9183255557524563, 4.285668576604249, 0.9879650550337685], "isController": false}, {"data": ["PUT User", 197, 0, 0.0, 227.4720812182741, 220, 286, 226.0, 234.0, 237.1, 247.7800000000004, 3.915411217553762, 4.282481019199428, 0.9876064253984974], "isController": false}, {"data": ["POST Book", 214, 0, 0.0, 256.43457943925205, 236, 996, 248.0, 263.0, 273.5, 604.9499999999996, 3.9638438171445505, 419.9516486881344, 18.423708596123213], "isController": false}, {"data": ["GET CoverPhotos for Book", 208, 0, 0.0, 230.99519230769235, 222, 257, 230.0, 241.0, 243.54999999999998, 253.73, 3.963188079949698, 2.7058426954918735, 0.5975893384524513], "isController": false}, {"data": ["PUT CoverPhoto", 203, 0, 0.0, 232.15270935960598, 224, 254, 230.0, 241.6, 244.0, 251.84000000000003, 3.9549563591022445, 81.39717311335917, 1.2255547349887002], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 5711, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
