/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9451851851851852, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "PUT Activity"], "isController": false}, {"data": [0.0, 500, 1500, "GET all Activity"], "isController": false}, {"data": [1.0, 500, 1500, "DELETE User"], "isController": false}, {"data": [1.0, 500, 1500, "GET Activitiy"], "isController": false}, {"data": [1.0, 500, 1500, "DELETE CoverPhoto"], "isController": false}, {"data": [1.0, 500, 1500, "GET Book"], "isController": false}, {"data": [0.87, 500, 1500, "GET all Author"], "isController": false}, {"data": [1.0, 500, 1500, "GET all User"], "isController": false}, {"data": [1.0, 500, 1500, "PUT Book"], "isController": false}, {"data": [1.0, 500, 1500, "PUT Author"], "isController": false}, {"data": [1.0, 500, 1500, "GET User"], "isController": false}, {"data": [1.0, 500, 1500, "POST Activity"], "isController": false}, {"data": [1.0, 500, 1500, "POST CoverPhoto"], "isController": false}, {"data": [1.0, 500, 1500, "GET Author"], "isController": false}, {"data": [1.0, 500, 1500, "GET CoverPhoto"], "isController": false}, {"data": [1.0, 500, 1500, "DELETE Author"], "isController": false}, {"data": [1.0, 500, 1500, "GET Author for Book"], "isController": false}, {"data": [1.0, 500, 1500, "GET all CoverPhoto"], "isController": false}, {"data": [0.87, 500, 1500, "GET all Book"], "isController": false}, {"data": [1.0, 500, 1500, "DELETE Activity"], "isController": false}, {"data": [1.0, 500, 1500, "POST Author"], "isController": false}, {"data": [0.99, 500, 1500, "DELETE Book"], "isController": false}, {"data": [1.0, 500, 1500, "POST User"], "isController": false}, {"data": [1.0, 500, 1500, "PUT User"], "isController": false}, {"data": [0.79, 500, 1500, "POST Book"], "isController": false}, {"data": [1.0, 500, 1500, "GET CoverPhotos for Book"], "isController": false}, {"data": [1.0, 500, 1500, "PUT CoverPhoto"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 1350, 0, 0.0, 340.3866666666673, 218, 2638, 232.0, 462.7000000000003, 721.1500000000049, 2557.3500000000004, 131.06796116504853, 2514.799188410194, 69.1284890776699], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["PUT Activity", 50, 0, 0.0, 229.46, 221, 262, 229.0, 234.0, 245.89999999999992, 262.0, 164.47368421052633, 551.6935649671053, 50.07773951480263], "isController": false}, {"data": ["GET all Activity", 50, 0, 0.0, 2326.12, 1904, 2638, 2356.0, 2618.0, 2626.25, 2638.0, 18.93939393939394, 63.71700402462121, 2.829811789772727], "isController": false}, {"data": ["DELETE User", 50, 0, 0.0, 226.67999999999998, 220, 241, 227.0, 231.0, 234.24999999999997, 241.0, 30.959752321981423, 16.538070820433436, 7.13827883126935], "isController": false}, {"data": ["GET Activitiy", 50, 0, 0.0, 229.86, 218, 264, 225.0, 252.8, 258.25, 264.0, 167.22408026755852, 112.45819397993311, 25.416753762541806], "isController": false}, {"data": ["DELETE CoverPhoto", 50, 0, 0.0, 232.81999999999994, 219, 275, 229.5, 253.9, 265.0999999999999, 275.0, 31.269543464665414, 16.70355495622264, 7.414912640712946], "isController": false}, {"data": ["GET Book", 50, 0, 0.0, 243.68000000000006, 223, 301, 238.0, 268.9, 293.45, 301.0, 32.341526520051744, 34.089990297542045, 4.76342678686934], "isController": false}, {"data": ["GET all Author", 50, 0, 0.0, 467.93999999999994, 241, 554, 490.0, 515.8, 534.9999999999999, 554.0, 83.75209380234506, 4502.03164258794, 12.26837311557789], "isController": false}, {"data": ["GET all User", 50, 0, 0.0, 226.38, 220, 253, 224.0, 233.9, 248.7, 253.0, 31.269543464665414, 34.2010631644778, 4.5194262038774236], "isController": false}, {"data": ["PUT Book", 50, 0, 0.0, 338.05999999999995, 249, 492, 307.5, 467.6, 477.9999999999999, 492.0, 29.533372711163615, 2822.407523626698, 132.8782579001772], "isController": false}, {"data": ["PUT Author", 50, 0, 0.0, 258.78, 226, 297, 256.5, 288.8, 295.45, 297.0, 72.67441860465117, 3170.5563567405525, 20.434002543604652], "isController": false}, {"data": ["GET User", 50, 0, 0.0, 225.9, 219, 257, 224.0, 231.0, 237.24999999999997, 257.0, 30.826140567200987, 19.455990867755855, 4.518558299938348], "isController": false}, {"data": ["POST Activity", 50, 0, 0.0, 234.84000000000006, 221, 272, 233.0, 249.39999999999998, 255.35, 272.0, 183.82352941176472, 618.4297449448529, 55.854348575367645], "isController": false}, {"data": ["POST CoverPhoto", 50, 0, 0.0, 232.28, 222, 282, 231.0, 241.0, 260.04999999999995, 282.0, 31.34796238244514, 645.1741281347962, 9.632151253918495], "isController": false}, {"data": ["GET Author", 50, 0, 0.0, 229.59999999999997, 220, 272, 228.0, 237.8, 252.59999999999988, 272.0, 79.23930269413628, 51.762455427892235, 11.825537341521395], "isController": false}, {"data": ["GET CoverPhoto", 50, 0, 0.0, 226.60000000000005, 219, 249, 225.0, 234.9, 242.35, 249.0, 31.387319522912744, 21.311499529190208, 4.8067963355304455], "isController": false}, {"data": ["DELETE Author", 50, 0, 0.0, 242.86, 222, 288, 231.0, 271.9, 273.45, 288.0, 75.87253414264036, 40.52956657814871, 17.6951939491654], "isController": false}, {"data": ["GET Author for Book", 50, 0, 0.0, 240.26000000000005, 224, 279, 237.5, 257.0, 266.84999999999997, 279.0, 159.2356687898089, 127.03087679140127, 24.075064689490446], "isController": false}, {"data": ["GET all CoverPhoto", 50, 0, 0.0, 230.54, 222, 250, 230.0, 237.0, 239.35, 250.0, 31.505986137366097, 648.4264236767486, 4.738204946439824], "isController": false}, {"data": ["GET all Book", 50, 0, 0.0, 439.74000000000007, 238, 902, 307.5, 889.9, 898.35, 902.0, 37.0919881305638, 3544.645133994807, 5.360951409495549], "isController": false}, {"data": ["DELETE Activity", 50, 0, 0.0, 231.22, 222, 266, 228.0, 237.0, 261.79999999999995, 266.0, 177.3049645390071, 94.7127105496454, 41.839816046099294], "isController": false}, {"data": ["POST Author", 50, 0, 0.0, 265.4, 225, 320, 255.0, 312.7, 316.45, 320.0, 76.4525993883792, 3900.0964616781343, 21.435098910550458], "isController": false}, {"data": ["DELETE Book", 50, 0, 0.0, 245.01999999999998, 221, 557, 230.5, 276.2, 311.6999999999999, 557.0, 30.50640634533252, 16.29590260829774, 7.055202295607077], "isController": false}, {"data": ["POST User", 50, 0, 0.0, 226.28000000000003, 219, 245, 225.0, 232.9, 238.04999999999995, 245.0, 31.133250311332503, 34.05199252801992, 7.850200420298878], "isController": false}, {"data": ["PUT User", 50, 0, 0.0, 230.67999999999998, 219, 257, 229.0, 247.8, 249.89999999999998, 257.0, 30.61849357011635, 33.488977342314755, 7.723395399571341], "isController": false}, {"data": ["POST Book", 50, 0, 0.0, 444.8400000000001, 277, 882, 332.0, 780.9, 854.9, 882.0, 29.533372711163615, 2822.7155474748965, 132.85460812906084], "isController": false}, {"data": ["GET CoverPhotos for Book", 50, 0, 0.0, 234.82, 221, 303, 231.0, 251.59999999999997, 294.25, 303.0, 30.26634382566586, 20.609488498789347, 4.5464541086561745], "isController": false}, {"data": ["PUT CoverPhoto", 50, 0, 0.0, 229.78000000000003, 222, 249, 228.0, 239.9, 246.35, 249.0, 31.367628607277293, 645.5788797835634, 9.663312617628607], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 1350, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
