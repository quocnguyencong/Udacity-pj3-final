/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9166666666666666, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "PUT Activity"], "isController": false}, {"data": [0.0, 500, 1500, "GET all Activity"], "isController": false}, {"data": [1.0, 500, 1500, "DELETE User"], "isController": false}, {"data": [1.0, 500, 1500, "GET Activitiy"], "isController": false}, {"data": [1.0, 500, 1500, "DELETE CoverPhoto"], "isController": false}, {"data": [1.0, 500, 1500, "GET Book"], "isController": false}, {"data": [0.55, 500, 1500, "GET all Author"], "isController": false}, {"data": [1.0, 500, 1500, "GET all User"], "isController": false}, {"data": [0.89, 500, 1500, "PUT Book"], "isController": false}, {"data": [0.93, 500, 1500, "PUT Author"], "isController": false}, {"data": [1.0, 500, 1500, "GET User"], "isController": false}, {"data": [1.0, 500, 1500, "POST Activity"], "isController": false}, {"data": [1.0, 500, 1500, "POST CoverPhoto"], "isController": false}, {"data": [1.0, 500, 1500, "GET Author"], "isController": false}, {"data": [1.0, 500, 1500, "GET CoverPhoto"], "isController": false}, {"data": [1.0, 500, 1500, "DELETE Author"], "isController": false}, {"data": [1.0, 500, 1500, "GET Author for Book"], "isController": false}, {"data": [1.0, 500, 1500, "GET all CoverPhoto"], "isController": false}, {"data": [0.67, 500, 1500, "GET all Book"], "isController": false}, {"data": [1.0, 500, 1500, "DELETE Activity"], "isController": false}, {"data": [0.95, 500, 1500, "POST Author"], "isController": false}, {"data": [1.0, 500, 1500, "DELETE Book"], "isController": false}, {"data": [1.0, 500, 1500, "POST User"], "isController": false}, {"data": [1.0, 500, 1500, "PUT User"], "isController": false}, {"data": [0.76, 500, 1500, "POST Book"], "isController": false}, {"data": [1.0, 500, 1500, "GET CoverPhotos for Book"], "isController": false}, {"data": [1.0, 500, 1500, "PUT CoverPhoto"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 1350, 0, 0.0, 403.67407407407404, 243, 3223, 261.0, 531.9000000000001, 1028.0, 3154.94, 110.43848167539267, 2243.110536904859, 59.43434151055301], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["PUT Activity", 50, 0, 0.0, 260.9000000000001, 248, 297, 258.0, 284.59999999999997, 287.0, 297.0, 134.77088948787062, 409.1823197439353, 42.481784871967655], "isController": false}, {"data": ["GET all Activity", 50, 0, 0.0, 2920.1600000000008, 2475, 3223, 2963.5, 3216.0, 3220.45, 3223.0, 15.47508511296812, 46.948143956979266, 2.478431600123801], "isController": false}, {"data": ["DELETE User", 50, 0, 0.0, 254.42000000000004, 246, 265, 254.0, 261.9, 263.0, 265.0, 25.163563160543532, 5.18507014343231, 6.0721840400100655], "isController": false}, {"data": ["GET Activitiy", 50, 0, 0.0, 256.54, 248, 316, 255.0, 265.9, 270.34999999999997, 316.0, 139.2757660167131, 47.97397284122563, 22.664954735376046], "isController": false}, {"data": ["DELETE CoverPhoto", 50, 0, 0.0, 265.31999999999994, 243, 344, 257.0, 293.0, 320.45, 344.0, 25.23977788995457, 5.2007745456839976, 6.256211351590106], "isController": false}, {"data": ["GET Book", 50, 0, 0.0, 276.8199999999998, 254, 331, 273.5, 299.7, 315.4, 331.0, 26.15062761506276, 18.983210479864017, 4.132514219403766], "isController": false}, {"data": ["GET all Author", 50, 0, 0.0, 526.04, 493, 577, 524.5, 556.2, 561.15, 577.0, 73.09941520467837, 3145.1951411732452, 11.493169773391813], "isController": false}, {"data": ["GET all User", 50, 0, 0.0, 254.98, 243, 269, 254.5, 262.9, 265.45, 269.0, 25.342118601115054, 19.402559553978712, 3.9349578687278255], "isController": false}, {"data": ["PUT Book", 50, 0, 0.0, 367.37999999999994, 277, 592, 329.5, 554.9, 589.35, 592.0, 26.399155227032733, 2513.965771845301, 119.06019007391764], "isController": false}, {"data": ["PUT Author", 50, 0, 0.0, 359.8199999999999, 250, 1157, 272.5, 790.8999999999999, 1058.1499999999996, 1157.0, 31.191515907673114, 1479.8083671241423, 9.105242124142233], "isController": false}, {"data": ["GET User", 50, 0, 0.0, 253.83999999999997, 243, 264, 253.0, 261.0, 262.0, 264.0, 25.0, 7.57568359375, 3.93310546875], "isController": false}, {"data": ["POST Activity", 50, 0, 0.0, 266.99999999999994, 247, 335, 264.0, 287.0, 302.6999999999999, 335.0, 122.54901960784314, 372.07509957107845, 38.55267693014706], "isController": false}, {"data": ["POST CoverPhoto", 50, 0, 0.0, 263.2200000000001, 251, 287, 262.0, 272.8, 281.7, 287.0, 26.413100898045432, 534.9426753169572, 8.399572437929212], "isController": false}, {"data": ["GET Author", 50, 0, 0.0, 258.68, 246, 294, 256.5, 269.7, 289.04999999999995, 294.0, 71.12375533428165, 23.120777027027028, 11.378411717638691], "isController": false}, {"data": ["GET CoverPhoto", 50, 0, 0.0, 255.70000000000005, 243, 277, 255.0, 263.9, 265.45, 277.0, 25.53626149131767, 8.959636746680285, 4.185054104954035], "isController": false}, {"data": ["DELETE Author", 50, 0, 0.0, 255.48, 244, 291, 253.5, 265.8, 273.04999999999995, 291.0, 72.78020378457059, 14.996702147016011, 17.755811044395923], "isController": false}, {"data": ["GET Author for Book", 50, 0, 0.0, 270.2599999999999, 248, 301, 268.5, 289.9, 294.79999999999995, 301.0, 127.55102040816327, 60.53441884566326, 20.654795121173468], "isController": false}, {"data": ["GET all CoverPhoto", 50, 0, 0.0, 268.24, 249, 377, 260.0, 297.0, 346.5999999999998, 377.0, 26.441036488630356, 535.5084528688525, 4.260518574828133], "isController": false}, {"data": ["GET all Book", 50, 0, 0.0, 750.7999999999998, 284, 1626, 687.5, 1098.9, 1547.7499999999998, 1626.0, 26.483050847457626, 3823.2214976165255, 4.112114340572034], "isController": false}, {"data": ["DELETE Activity", 50, 0, 0.0, 269.1199999999999, 248, 302, 268.0, 283.9, 298.25, 302.0, 124.37810945273633, 25.628692475124378, 30.686411691542286], "isController": false}, {"data": ["POST Author", 50, 0, 0.0, 310.62000000000006, 249, 554, 279.0, 511.7999999999997, 542.1999999999999, 554.0, 73.52941176470588, 3458.030790441176, 21.40538832720588], "isController": false}, {"data": ["DELETE Book", 50, 0, 0.0, 265.4800000000001, 245, 322, 260.0, 282.9, 311.25, 322.0, 26.164311878597594, 5.391279107796965, 6.332070087650445], "isController": false}, {"data": ["POST User", 50, 0, 0.0, 255.54, 243, 269, 255.5, 263.0, 267.45, 269.0, 25.290844714213456, 19.363302984319674, 6.6487259736975215], "isController": false}, {"data": ["PUT User", 50, 0, 0.0, 254.57999999999998, 243, 271, 253.0, 263.0, 265.9, 271.0, 24.91280518186348, 19.073866467364223, 6.551775815894369], "isController": false}, {"data": ["POST Book", 50, 0, 0.0, 438.40000000000003, 264, 653, 335.5, 606.1, 624.7499999999999, 653.0, 26.12330198537095, 2487.850623693835, 117.79517290360502], "isController": false}, {"data": ["GET CoverPhotos for Book", 50, 0, 0.0, 258.1600000000001, 246, 290, 256.0, 270.7, 282.04999999999995, 290.0, 26.525198938992045, 9.35842175066313, 4.269417274535809], "isController": false}, {"data": ["PUT CoverPhoto", 50, 0, 0.0, 261.69999999999993, 247, 369, 259.0, 269.9, 274.45, 369.0, 25.367833587011667, 513.7729499619483, 8.087483352359207], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 1350, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
